package maze;

public enum Direction {
	LEFT, RIGHT, UP, DOWN
}
