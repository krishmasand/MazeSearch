package maze;

public enum PointType {
	WALL, EMPTY, DOT, START, CHARACTER
}
